"""Main incident processing orchestration service."""
import structlog
from typing import Dict, Any, List, Optional
from datetime import datetime

from app.services.servicenow import ServiceNowConnector
from app.services.openai_service import OpenAIConnector
from app.services.agentic_service import AgenticAIService
from app.services.compliance import ComplianceFilter
from app.models.incident import IncidentProcessRequest, IncidentSummary
from app.abstracts.compliance import ComplianceLevel
from app.exceptions.servicenow import ServiceNowNotFoundError

logger = structlog.get_logger(__name__)


class IncidentProcessor:
    """Main orchestration service for incident processing."""
    
    def __init__(self):
        self.servicenow = ServiceNowConnector()
        self.openai_service = OpenAIConnector()
        self.agentic_service = AgenticAIService()
        self.compliance_filter = ComplianceFilter()
        self._initialized = False
    
    async def _ensure_initialized(self) -> None:
        """Ensure all services are initialized."""
        if not self._initialized:
            await self.servicenow.initialize()
            await self.openai_service.initialize()
            await self.agentic_service.initialize()
            await self.compliance_filter.initialize()
            self._initialized = True
            logger.info("Incident processor initialized")
    
    async def process_incident(self, request: IncidentProcessRequest) -> Dict[str, Any]:
        """
        Main incident processing workflow.
        
        Args:
            request: Incident processing request
            
        Returns:
            Complete processing results including incident data, AI analysis, and compliance info
        """
        await self._ensure_initialized()
        
        start_time = datetime.now()
        logger.info("Starting incident processing workflow", 
                   sys_id=request.sys_id,
                   analysis_type=request.analysis_type,
                   compliance_level=request.compliance_level)
        
        try:
            # Step 1: Fetch incident from ServiceNow
            logger.info("Fetching incident from ServiceNow", sys_id=request.sys_id)
            incident = await self.servicenow.get_incident(request.sys_id)
            
            # Convert to dict for processing
            incident_dict = incident.model_dump()
            
            # Step 2: Apply compliance filtering
            logger.info("Applying compliance filtering", 
                       compliance_level=request.compliance_level)
            
            compliance_level = ComplianceLevel(request.compliance_level)
            compliance_result = await self.compliance_filter.filter_data(
                incident_dict, compliance_level
            )
            
            # Step 3: Perform AI analysis on filtered data
            logger.info("Performing AI analysis", analysis_type=request.analysis_type)
            
            ai_analysis = await self.openai_service.analyze_incident(
                compliance_result.filtered_data,
                request.analysis_type
            )
            
            # Step 4: Get agentic insights (optional)
            agentic_insights = None
            if request.analysis_type in ["priority_assessment", "classification", "recommendations"]:
                logger.info("Getting agentic insights")
                
                if request.analysis_type == "priority_assessment":
                    agentic_result = await self.agentic_service.analyze_incident_priority(
                        compliance_result.filtered_data
                    )
                elif request.analysis_type == "classification":
                    agentic_result = await self.agentic_service.classify_incident_type(
                        compliance_result.filtered_data
                    )
                elif request.analysis_type == "recommendations":
                    agentic_result = await self.agentic_service.recommend_actions(
                        compliance_result.filtered_data
                    )
                
                agentic_insights = agentic_result.result
            
            # Step 5: Get incident history if requested
            history = None
            if request.include_history:
                logger.info("Fetching incident history")
                history = await self.servicenow.get_incident_history(request.sys_id)
            
            processing_time = (datetime.now() - start_time).total_seconds()
            
            result = {
                "incident": incident,
                "ai_analysis": {
                    "content": ai_analysis.content,
                    "model": ai_analysis.model,
                    "analysis_type": request.analysis_type,
                    "usage": ai_analysis.usage
                },
                "agentic_insights": agentic_insights,
                "compliance_info": {
                    "compliance_level": request.compliance_level,
                    "compliance_score": compliance_result.compliance_score,
                    "removed_fields": compliance_result.removed_fields,
                    "masked_fields": compliance_result.masked_fields,
                    "classifications": [c.model_dump() for c in compliance_result.classifications]
                },
                "history": history,
                "processing_metadata": {
                    "processing_time": processing_time,
                    "timestamp": datetime.now().isoformat(),
                    "services_used": ["servicenow", "openai", "compliance"]
                }
            }
            
            logger.info("Incident processing completed successfully", 
                       sys_id=request.sys_id,
                       processing_time=processing_time)
            
            return result
            
        except Exception as e:
            processing_time = (datetime.now() - start_time).total_seconds()
            logger.error("Error in incident processing workflow", 
                        sys_id=request.sys_id,
                        error=str(e),
                        processing_time=processing_time)
            raise
    
    async def get_incident_summary(self, sys_id: str) -> IncidentSummary:
        """Get a summary of an incident."""
        await self._ensure_initialized()
        
        try:
            incident = await self.servicenow.get_incident(sys_id)
            
            return IncidentSummary(
                sys_id=incident.sys_id,
                number=incident.number,
                title=incident.short_description,
                status=incident.state,
                priority=incident.priority,
                created=incident.opened_at,
                updated=incident.updated_at,
                assigned_to=incident.assigned_to,
                summary=incident.description[:200] + "..." if incident.description and len(incident.description) > 200 else incident.description
            )
            
        except Exception as e:
            logger.error("Error getting incident summary", sys_id=sys_id, error=str(e))
            raise
    
    async def analyze_incident_only(self, sys_id: str, analysis_type: str = "general") -> Dict[str, Any]:
        """Perform only AI analysis on an incident."""
        await self._ensure_initialized()
        
        try:
            incident = await self.servicenow.get_incident(sys_id)
            incident_dict = incident.model_dump()
            
            # Apply basic compliance filtering for analysis
            compliance_result = await self.compliance_filter.filter_data(
                incident_dict, ComplianceLevel.INTERNAL
            )
            
            ai_analysis = await self.openai_service.analyze_incident(
                compliance_result.filtered_data,
                analysis_type
            )
            
            return {
                "content": ai_analysis.content,
                "model": ai_analysis.model,
                "analysis_type": analysis_type,
                "usage": ai_analysis.usage
            }
            
        except Exception as e:
            logger.error("Error analyzing incident", sys_id=sys_id, error=str(e))
            raise
    
    async def filter_incident_data_only(self, sys_id: str, compliance_level: str = "internal") -> Dict[str, Any]:
        """Apply only compliance filtering to incident data."""
        await self._ensure_initialized()
        
        try:
            incident = await self.servicenow.get_incident(sys_id)
            incident_dict = incident.model_dump()
            
            compliance_result = await self.compliance_filter.filter_data(
                incident_dict, ComplianceLevel(compliance_level)
            )
            
            return {
                "filtered_data": compliance_result.filtered_data,
                "compliance_score": compliance_result.compliance_score,
                "removed_fields": compliance_result.removed_fields,
                "masked_fields": compliance_result.masked_fields,
                "classifications": [c.model_dump() for c in compliance_result.classifications]
            }
            
        except Exception as e:
            logger.error("Error filtering incident data", sys_id=sys_id, error=str(e))
            raise
    
    async def get_incident_history(self, sys_id: str) -> List[Dict[str, Any]]:
        """Get incident history."""
        await self._ensure_initialized()
        
        try:
            return await self.servicenow.get_incident_history(sys_id)
        except Exception as e:
            logger.error("Error getting incident history", sys_id=sys_id, error=str(e))
            raise
    
    async def cleanup(self) -> None:
        """Cleanup resources."""
        if self._initialized:
            await self.servicenow.disconnect()
            await self.openai_service.disconnect()
            await self.agentic_service.disconnect()
            logger.info("Incident processor cleanup completed")
