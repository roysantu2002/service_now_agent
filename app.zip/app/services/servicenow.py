"""ServiceNow integration service implementation."""
import httpx
import structlog
from typing import Dict, Any, List, Optional
from datetime import datetime

from app.abstracts.servicenow_connector import (
    BaseServiceNowConnector,
    IncidentData,
    ServiceNowQuery,
    ServiceNowResponse
)
from app.core.config import get_settings
from app.exceptions.servicenow import ServiceNowError, ServiceNowNotFoundError

logger = structlog.get_logger(__name__)

class ServiceNowConnector(BaseServiceNowConnector):
    """ServiceNow REST API connector implementation."""
    
    def __init__(self):
        super().__init__()
        self.settings = get_settings()
        self.base_url = self.settings.SERVICE_NOW_REST_API_URL.rstrip('/')
        self.username = self.settings.SERVICE_NOW_USER
        self.password = self.settings.SERVICE_NOW_PASSWORD
        self.timeout = 10  # default timeout
        self.client: Optional[httpx.AsyncClient] = None
    
    async def initialize(self) -> None:
        if not self.client:
            self.client = httpx.AsyncClient(
                auth=(self.username, self.password),
                timeout=self.timeout,
                headers={
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            )
            logger.info("ServiceNow connector initialized", base_url=self.base_url)
    
    async def health_check(self) -> bool:
        try:
            await self.initialize()
            response = await self.client.get(f"{self.base_url}/api/now/table/sys_user")
            return response.status_code == 200
        except Exception as e:
            logger.error("ServiceNow health check failed", error=str(e))
            return False
    
    async def disconnect(self) -> None:
        if self.client:
            await self.client.aclose()
            self.client = None
            logger.info("ServiceNow connection closed")
