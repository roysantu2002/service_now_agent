"""Health check endpoints."""
from fastapi import APIRouter, Depends
from typing import Dict, Any
import structlog

from app.services.servicenow import ServiceNowConnector
from app.services.openai_service import OpenAIConnector
from app.services.compliance import ComplianceFilter

logger = structlog.get_logger(__name__)
router = APIRouter()


@router.get("/")
async def health_check() -> Dict[str, Any]:
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "service": "ServiceNow Incident Processor",
        "version": "1.0.0"
    }


@router.get("/detailed")
async def detailed_health_check() -> Dict[str, Any]:
    """Detailed health check for all services."""
    logger.info("Performing detailed health check")
    
    # Initialize services
    servicenow = ServiceNowConnector()
    openai_service = OpenAIConnector()
    compliance_filter = ComplianceFilter()
    
    health_status = {
        "status": "healthy",
        "timestamp": "2024-01-01T00:00:00Z",
        "services": {}
    }
    
    # Check ServiceNow
    try:
        servicenow_healthy = await servicenow.health_check()
        health_status["services"]["servicenow"] = {
            "status": "healthy" if servicenow_healthy else "unhealthy",
            "details": "ServiceNow API connection"
        }
    except Exception as e:
        health_status["services"]["servicenow"] = {
            "status": "unhealthy",
            "details": f"Error: {str(e)}"
        }
    
    # Check OpenAI
    try:
        openai_healthy = await openai_service.health_check()
        health_status["services"]["openai"] = {
            "status": "healthy" if openai_healthy else "unhealthy",
            "details": "OpenAI API connection"
        }
    except Exception as e:
        health_status["services"]["openai"] = {
            "status": "unhealthy",
            "details": f"Error: {str(e)}"
        }
    
    # Check Compliance Filter
    try:
        compliance_healthy = await compliance_filter.health_check()
        health_status["services"]["compliance"] = {
            "status": "healthy" if compliance_healthy else "unhealthy",
            "details": "Compliance filtering service"
        }
    except Exception as e:
        health_status["services"]["compliance"] = {
            "status": "unhealthy",
            "details": f"Error: {str(e)}"
        }
    
    # Overall status
    all_healthy = all(
        service["status"] == "healthy" 
        for service in health_status["services"].values()
    )
    health_status["status"] = "healthy" if all_healthy else "degraded"
    
    # Cleanup connections
    await servicenow.disconnect()
    await openai_service.disconnect()
    
    logger.info("Health check completed", overall_status=health_status["status"])
    
    return health_status


@router.get("/servicenow-test")
async def test_servicenow_connection() -> Dict[str, Any]:
    """Test ServiceNow connection with detailed debugging info."""
    logger.info("Testing ServiceNow connection")
    
    servicenow = ServiceNowConnector()
    
    try:
        # Test basic connection
        await servicenow.initialize()
        
        # Validate credentials
        credentials_valid = servicenow.validate_credentials()
        
        # Test connection
        connection_test = await servicenow.test_connection()
        
        # Try to fetch a single incident (limit 1)
        test_result = {
            "credentials_valid": credentials_valid,
            "connection_test": connection_test,
            "base_url": servicenow.base_url,
            "username": servicenow.username[:3] + "***" if servicenow.username else None,
            "status": "success" if connection_test else "failed"
        }
        
        if connection_test:
            # Try a simple query to test JSON parsing
            try:
                response = await servicenow.client.get(
                    f"{servicenow.base_url}/api/now/table/incident",
                    params={'sysparm_limit': 1}
                )
                
                test_result["api_response"] = {
                    "status_code": response.status_code,
                    "content_type": response.headers.get('content-type'),
                    "content_length": len(response.content),
                    "is_json": 'application/json' in response.headers.get('content-type', '').lower()
                }
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        test_result["sample_data"] = {
                            "has_result": 'result' in data,
                            "result_count": len(data.get('result', [])),
                            "result_type": type(data.get('result', None)).__name__
                        }
                    except ValueError as e:
                        test_result["json_error"] = str(e)
                        test_result["response_preview"] = response.text[:200]
                
            except Exception as e:
                test_result["query_error"] = str(e)
        
        await servicenow.disconnect()
        return test_result
        
    except Exception as e:
        logger.error("ServiceNow connection test failed", error=str(e))
        await servicenow.disconnect()
        return {
            "status": "error",
            "error": str(e),
            "credentials_valid": False,
            "connection_test": False
        }
