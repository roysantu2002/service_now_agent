"""Incident processing endpoints."""
from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, Any, Optional
import structlog
from datetime import datetime

from app.models.incident import (
    IncidentProcessRequest,
    IncidentProcessResponse,
    IncidentSummary
)
from app.services.incident_processor import IncidentProcessor
from app.exceptions.servicenow import ServiceNowNotFoundError, ServiceNowError

logger = structlog.get_logger(__name__)
router = APIRouter()


def get_incident_processor() -> IncidentProcessor:
    """Dependency to provide an IncidentProcessor instance."""
    return IncidentProcessor()


@router.post("/process/{sys_id}", response_model=IncidentProcessResponse)
async def process_incident(
    sys_id: str,
    request: Optional[IncidentProcessRequest] = None,
    processor: IncidentProcessor = Depends(get_incident_processor)
) -> IncidentProcessResponse:
    """Process a ServiceNow incident."""
    start_time = datetime.utcnow()

    if not request:
        request = IncidentProcessRequest(sys_id=sys_id)
    else:
        request.sys_id = sys_id

    logger.info("Processing incident request", sys_id=sys_id)

    try:
        result = await processor.process_incident(request)
        processing_time = (datetime.utcnow() - start_time).total_seconds()

        response = IncidentProcessResponse(
            success=True,
            incident=result.get("incident"),
            ai_analysis=result.get("ai_analysis"),
            compliance_info=result.get("compliance_info"),
            processing_time=processing_time,
            message="Incident processed successfully"
        )

        logger.info("Incident processing completed", sys_id=sys_id, processing_time=processing_time)
        return response

    except ServiceNowNotFoundError:
        logger.warning("Incident not found", sys_id=sys_id)
        raise HTTPException(status_code=404, detail=f"Incident with sys_id '{sys_id}' not found")

    except ServiceNowError as e:
        logger.error("ServiceNow error processing incident", sys_id=sys_id, error=str(e))
        raise HTTPException(status_code=502, detail=f"ServiceNow error: {str(e)}")

    except Exception as e:
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        logger.error("Error processing incident", sys_id=sys_id, error=str(e), processing_time=processing_time)
        return IncidentProcessResponse(
            success=False,
            processing_time=processing_time,
            message="Failed to process incident",
            errors=[str(e)]
        )


@router.get("/{sys_id}/summary", response_model=IncidentSummary)
async def get_incident_summary(
    sys_id: str,
    processor: IncidentProcessor = Depends(get_incident_processor)
) -> IncidentSummary:
    """Get summary of a ServiceNow incident."""
    logger.info("Getting incident summary", sys_id=sys_id)

    try:
        summary = await processor.get_incident_summary(sys_id)
        logger.info("Incident summary retrieved", sys_id=sys_id)
        return summary

    except ServiceNowNotFoundError:
        logger.warning("Incident not found for summary", sys_id=sys_id)
        raise HTTPException(status_code=404, detail=f"Incident with sys_id '{sys_id}' not found")

    except Exception as e:
        logger.error("Error getting incident summary", sys_id=sys_id, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get incident summary: {str(e)}")


@router.get("/{sys_id}/details")
async def get_incident_details(
    sys_id: str,
    processor: IncidentProcessor = Depends(get_incident_processor)
) -> Dict[str, Any]:
    """Get raw incident details from ServiceNow."""
    logger.info("Getting incident details", sys_id=sys_id)

    try:
        # Local import to avoid circular import
        from app.services.servicenow import ServiceNowConnector

        connector: ServiceNowConnector = processor.servicenow
        incident_data = await connector.get_incident(sys_id)

        logger.info("Incident details retrieved", sys_id=sys_id)
        return {
            "success": True,
            "sys_id": sys_id,
            "incident": incident_data.dict(),
            "message": "Incident details retrieved successfully"
        }

    except ServiceNowNotFoundError:
        logger.warning("Incident not found for details", sys_id=sys_id)
        raise HTTPException(status_code=404, detail=f"Incident with sys_id '{sys_id}' not found")

    except ServiceNowError as e:
        logger.error("ServiceNow error getting incident details", sys_id=sys_id, error=str(e))
        raise HTTPException(status_code=502, detail=f"ServiceNow error: {str(e)}")

    except Exception as e:
        logger.error("Error getting incident details", sys_id=sys_id, error=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to get incident details: {str(e)}")
