"""Main API router for v1 endpoints."""
from fastapi import APIRouter

print("[DEBUG] Starting router.py imports...")

try:
    from app.api.v1.endpoints import health
    print("[DEBUG] Health endpoint imported successfully")
except Exception as e:
    print(f"[DEBUG] Error importing health: {e}")

try:
    from app.api.v1.endpoints import incidents
    print(f"[DEBUG] Incidents endpoint imported successfully, routes: {len(incidents.router.routes)}")
except Exception as e:
    print(f"[DEBUG] Error importing incidents: {e}")

api_router = APIRouter()

# Include endpoint routers
print("[DEBUG] Including health router...")
api_router.include_router(health.router, prefix="/health", tags=["health"])

print("[DEBUG] Including incidents router...")
api_router.include_router(incidents.router, prefix="/incidents", tags=["incidents"])

print(f"[DEBUG] Final API router has {len(api_router.routes)} routes")
for route in api_router.routes:
    print(f"[DEBUG] API Route: {route.path} - {getattr(route, 'methods', 'N/A')}")
