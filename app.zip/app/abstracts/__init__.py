"""Abstract base classes and interfaces."""
